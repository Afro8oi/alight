import type { ReactNode } from "react";

export function Flame({ size = 19 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 2c2.5 3.6 4.5 6 4.5 9a4.5 4.5 0 0 1-9 0c0-3 2-5.4 4.5-9Z" />
      <path d="M9 21h6" />
    </svg>
  );
}

export function Wordmark() {
  return (
    <>
      <span className="mark" aria-hidden="true"><Flame /></span>
      <span className="wordmark">A<em>li</em>ght</span>
    </>
  );
}

const PATHS: Record<string, ReactNode> = {
  home: <><path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1v-9.5Z" /></>,
  circles: <><circle cx="9" cy="9" r="4.2" /><circle cx="16" cy="15" r="4.2" /></>,
  review: <><rect x="4" y="3.5" width="16" height="17" rx="3" /><path d="m8.5 12 2.5 2.5 4.5-5" /></>,
  shield: <><path d="M12 3l7 3v5.5c0 4.3-2.9 8.1-7 9.5-4.1-1.4-7-5.2-7-9.5V6l7-3Z" /><path d="m9 12 2 2 4-4" /></>,
  check: <><path d="M20 6 9 17l-5-5" /></>,
  clock: <><circle cx="12" cy="12" r="8.5" /><path d="M12 8v4l3 2" /></>,
  back: <><path d="M15 5l-7 7 7 7" /></>,
  report: <><path d="M7 3.5h7.5L19 8v12.5H7Z" /><path d="M14 3.5V8h5" /><path d="M9.8 12.5h6M9.8 16h4" /></>,
};

export function Icon({ name, size = 20, width = 1.9 }: { name: keyof typeof PATHS | string; size?: number; width?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {PATHS[name]}
    </svg>
  );
}

export function Avatar({ seed, name, small }: { seed: number; name: string; small?: boolean }) {
  const s = Math.min(4, Math.max(1, seed || 1));
  return (
    <span className={`av s${s}${small ? " sm" : ""}`} aria-hidden="true">
      {(name || "?").trim().charAt(0).toUpperCase()}
    </span>
  );
}

export function StatusChip({ status }: { status: string }) {
  if (status === "approved")
    return <span className="chip ok"><Icon name="check" size={12} width={2.6} />Reviewed</span>;
  if (status === "pending")
    return <span className="chip wait"><Icon name="clock" size={12} width={2.2} />In review</span>;
  if (status === "returned")
    return <span className="chip bad">Returned</span>;
  return <span className="chip">Removed</span>;
}

export function ArtPanel({ id }: { id: number }) {
  return (
    <div className="art" data-art={id} role="img" aria-label="Alight art card">
      <span className="cred">Alight art pack</span>
    </div>
  );
}

export function timeAgo(iso: string) {
  const then = new Date(iso).getTime();
  const mins = Math.max(0, Math.round((Date.now() - then) / 60000));
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} h ago`;
  const days = Math.round(hrs / 24);
  if (days < 7) return `${days} d ago`;
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

export const TIERS = [
  { id: "sprouts", n: "Sprouts", age: "11–12", p: "Circle only. No private messages at all, comments off, a leader present in every thread." },
  { id: "roots", n: "Roots", age: "13–15", p: "Messages with confirmed circle members. Comments on and filtered. Parent gets a weekly digest." },
  { id: "branches", n: "Branches", age: "16–17", p: "Messages with mutual friends. Can co-lead a circle thread. Parent sees summaries, not content." },
  { id: "open", n: "Open", age: "18–25", p: "Full community and leader tools. Cannot see or contact any minor outside a circle they help lead." },
] as const;

export const CAPS = [
  { c: "Private messages", sprouts: ["off", "None"], roots: ["on", "Confirmed circle"], branches: ["on", "Mutual friends"], open: ["on", "Community"] },
  { c: "Every upload reviewed before publish", sprouts: ["on", "Always"], roots: ["on", "Always"], branches: ["on", "Always"], open: ["on", "Always"] },
  { c: "Comments", sprouts: ["off", "Off"], roots: ["sup", "Filtered"], branches: ["sup", "Filtered"], open: ["on", "On"] },
  { c: "Discoverable outside circles", sprouts: ["off", "Never"], roots: ["off", "Never"], branches: ["off", "Never"], open: ["sup", "Opt in"] },
  { c: "Camera roll access", sprouts: ["off", "None"], roots: ["off", "None"], branches: ["off", "None"], open: ["sup", "On request"] },
  { c: "Live video", sprouts: ["off", "Off"], roots: ["off", "Off"], branches: ["off", "Off"], open: ["sup", "Leader only"] },
  { c: "Parent visibility", sprouts: ["on", "Full activity"], roots: ["on", "Weekly digest"], branches: ["sup", "Summary only"], open: ["off", "None"] },
  { c: "Daily time cap", sprouts: ["on", "45 min"], roots: ["on", "60 min"], branches: ["sup", "Self-set"], open: ["off", "None"] },
  { c: "Leader tools", sprouts: ["off", "No"], roots: ["off", "No"], branches: ["sup", "Co-lead"], open: ["on", "Yes"] },
] as const;
