"use client";

import { useFormStatus } from "react-dom";

type Props = {
  children: React.ReactNode;
  pendingLabel?: string;
  className?: string;
  name?: string;
  value?: string;
  style?: React.CSSProperties;
};

// A submit button that disables itself while its form is in flight, so a
// double-tap cannot send the same thing twice.
export function SubmitButton({
  children,
  pendingLabel,
  className = "btn pri",
  name,
  value,
  style,
}: Props) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      className={className}
      name={name}
      value={value}
      style={style}
      disabled={pending}
      aria-busy={pending}
    >
      {pending ? (pendingLabel ?? "Sending…") : children}
    </button>
  );
}
