"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon } from "./ui";

type Item = { href: string; label: string; icon: string; tick?: number };

export function Rail({ items }: { items: Item[] }) {
  const path = usePathname();
  return (
    <nav className="rail" aria-label="Primary">
      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        {items.map((i) => {
          const on = i.href === "/app" ? path === "/app" : path.startsWith(i.href);
          return (
            <Link key={i.href} href={i.href} className={`navitem${on ? " on" : ""}`}
              aria-current={on ? "page" : undefined}>
              <Icon name={i.icon} />
              <span>{i.label}</span>
              {i.tick ? <span className="tick num">{i.tick}</span> : null}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function TabBar({ items }: { items: Item[] }) {
  const path = usePathname();
  return (
    <nav className="tabbar" aria-label="Primary">
      {items.map((i) => {
        const on = i.href === "/app" ? path === "/app" : path.startsWith(i.href);
        return (
          <Link key={i.href} href={i.href} className={`tab${on ? " on" : ""}`}
            aria-current={on ? "page" : undefined}>
            <Icon name={i.icon} size={22} />
            <span>{i.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
