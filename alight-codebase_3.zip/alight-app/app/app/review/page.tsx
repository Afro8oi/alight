import { redirect } from "next/navigation";
import { supabaseServer, type PostCard } from "@/lib/supabase";
import { Avatar, ArtPanel, timeAgo } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { reviewAction } from "@/app/actions";

export const dynamic = "force-dynamic";

export default async function ReviewQueue({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: memberships } = await supabase
    .from("circle_members")
    .select("circle_id, role")
    .eq("profile_id", user!.id);

  const leaderCircles = (memberships ?? [])
    .filter((m) => m.role === "leader" || m.role === "safeguarding_lead")
    .map((m) => m.circle_id);

  if (!leaderCircles.length) redirect("/app");

  const { data: queue } = await supabase
    .from("post_cards")
    .select("*")
    .eq("status", "pending")
    .in("circle_id", leaderCircles)
    .order("created_at", { ascending: true });

  const { data: recent } = await supabase
    .from("post_reviews")
    .select("id, decision, note, created_at")
    .order("created_at", { ascending: false })
    .limit(8);

  const items = (queue ?? []) as PostCard[];

  return (
    <>
      <div className="vhead">
        <h1>Review queue</h1>
        <p>
          Nothing below has been seen by anyone but its author and you. Approving publishes it to the
          circle; returning it sends your note back to the young person so they can try again.
        </p>
      </div>

      {error ? <div className="alert" style={{ marginBottom: 14 }}>{error}</div> : null}

      {items.length === 0 ? (
        <div className="empty">Queue clear. Nothing is waiting on a human right now.</div>
      ) : (
        <div className="feed">
          {items.map((p) => (
            <article key={p.id} className="post">
              <div className="phead">
                <Avatar seed={p.avatar_seed} name={p.display_name} />
                <div style={{ minWidth: 0 }}>
                  <div className="pname">{p.display_name}</div>
                  <div className="pmeta">@{p.handle} · {timeAgo(p.created_at)} · {p.circle_name}</div>
                </div>
                <div className="spacer" />
                <span className="chip wait">Waiting {timeAgo(p.created_at)}</span>
              </div>

              <div className="pbody">{p.body}</div>
              {p.art_id ? <ArtPanel id={p.art_id} /> : null}

              <div style={{ padding: 14, borderTop: "1px solid var(--line-soft)" }}>
                <form action={reviewAction} className="stack" style={{ gap: 10 }}>
                  <input type="hidden" name="post_id" value={p.id} />
                  <input
                    type="text"
                    name="note"
                    maxLength={300}
                    placeholder="Note back to the author (needed if you are returning it)"
                  />
                  <div className="row" style={{ gap: 8 }}>
                    <SubmitButton className="btn ok" name="decision" value="approve" pendingLabel="Publishing…">
                      Approve and publish
                    </SubmitButton>
                    <SubmitButton className="btn no" name="decision" value="return" pendingLabel="Returning…">
                      Return with a note
                    </SubmitButton>
                    <SubmitButton className="btn ghost sm" name="decision" value="remove" pendingLabel="Removing…">
                      Remove
                    </SubmitButton>
                  </div>
                </form>
              </div>
            </article>
          ))}
        </div>
      )}

      <div className="panel" style={{ marginTop: 18 }}>
        <div className="lab">Audit trail</div>
        <h3 style={{ marginTop: 6, fontSize: 17 }}>Your last decisions</h3>
        <p className="dim" style={{ fontSize: 13.5, marginTop: 6 }}>
          Every review is written to the database with the reviewer, the decision and the time. It can be
          handed to a church safeguarding officer as it stands.
        </p>
        <div className="stack" style={{ marginTop: 12, gap: 8 }}>
          {(recent ?? []).length === 0 ? (
            <span className="faint" style={{ fontSize: 14 }}>No decisions recorded yet.</span>
          ) : (
            (recent ?? []).map((r) => (
              <div key={r.id} className="row" style={{ gap: 10, fontSize: 14 }}>
                <span className={`state ${r.decision === "approve" ? "on" : "sup"}`}>{r.decision}</span>
                <span className="dim">{r.note ?? "no note"}</span>
                <span className="spacer" />
                <span className="pmeta">{timeAgo(r.created_at)}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}
