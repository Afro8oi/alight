import { supabaseServer } from "@/lib/supabase";
import { Avatar } from "@/components/ui";
import { createInviteAction } from "@/app/actions";

export const dynamic = "force-dynamic";

const ROLE_LABEL: Record<string, string> = {
  member: "Member",
  leader: "Leader",
  safeguarding_lead: "Safeguarding lead",
};

type Person = { role: string; display_name: string; handle: string; avatar_seed: number; tier: string };
type Invite = { code: string; grants_role: string; uses: number; max_uses: number };
type CircleBlock = {
  id: string;
  name: string;
  church_name: string | null;
  description: string | null;
  myRole: string;
  isLeader: boolean;
  people: Person[];
  invites: Invite[];
};

export default async function Circles({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: memberships } = await supabase
    .from("circle_members")
    .select("circle_id, role, circles(id, name, church_name, description)")
    .eq("profile_id", user!.id);

  const blocks: CircleBlock[] = [];

  for (const m of memberships ?? []) {
    const circle = m.circles as unknown as {
      id: string; name: string; church_name: string | null; description: string | null;
    } | null;
    if (!circle) continue;

    const isLeader = m.role === "leader" || m.role === "safeguarding_lead";

    const { data: peopleRows } = await supabase
      .from("circle_members")
      .select("role, profiles(display_name, handle, avatar_seed, tier)")
      .eq("circle_id", circle.id);

    const people: Person[] = (peopleRows ?? []).flatMap((p) => {
      const prof = p.profiles as unknown as
        { display_name: string; handle: string; avatar_seed: number; tier: string } | null;
      return prof ? [{ role: p.role as string, ...prof }] : [];
    });

    let invites: Invite[] = [];
    if (isLeader) {
      const { data } = await supabase
        .from("circle_invites")
        .select("code, grants_role, uses, max_uses")
        .eq("circle_id", circle.id)
        .order("created_at", { ascending: false });
      invites = (data ?? []) as Invite[];
    }

    blocks.push({ ...circle, myRole: m.role as string, isLeader, people, invites });
  }

  return (
    <>
      <div className="vhead">
        <h1>Circles</h1>
        <p>
          A circle is a real group that meets somewhere — a youth group, a small group, a camp cohort.
          There is no public directory and no way in except a code.
        </p>
      </div>

      {error ? <div className="alert" style={{ marginBottom: 14 }}>{error}</div> : null}

      {blocks.length === 0 ? (
        <div className="empty">You are not in a circle yet. Enter your leader&apos;s code to join one.</div>
      ) : null}

      {blocks.map((c) => (
        <div className="panel" key={c.id}>
          <h3 style={{ fontSize: 19 }}>{c.name}</h3>
          <div className="pmeta">
            {c.church_name ? `${c.church_name} · ` : ""}
            {c.people.length} members · you are {ROLE_LABEL[c.myRole] ?? c.myRole}
          </div>
          {c.description ? (
            <p className="dim" style={{ fontSize: 14.5, marginTop: 10 }}>{c.description}</p>
          ) : null}

          <div className="divider" />
          <div className="lab">Who is here</div>
          <div className="stack" style={{ marginTop: 10, gap: 8 }}>
            {c.people.map((p, i) => (
              <div className="row" key={`${p.handle}-${i}`} style={{ gap: 10 }}>
                <Avatar seed={p.avatar_seed} name={p.display_name} small />
                <span style={{ fontSize: 14.5, fontWeight: 650 }}>{p.display_name}</span>
                <span className="pmeta">@{p.handle}</span>
                <span className="spacer" />
                {p.role !== "member" ? (
                  <span className="chip led">{ROLE_LABEL[p.role]}</span>
                ) : (
                  <span className="chip">{p.tier}</span>
                )}
              </div>
            ))}
          </div>

          {c.isLeader ? (
            <>
              <div className="divider" />
              <div className="lab">Invite codes</div>
              <p className="dim" style={{ fontSize: 13.5, marginTop: 6 }}>
                Hand these out in person or through your church&apos;s own channels. Each one expires
                after 30 days.
              </p>
              <div className="stack" style={{ marginTop: 12, gap: 10 }}>
                {c.invites.length === 0 ? (
                  <span className="faint" style={{ fontSize: 14 }}>No codes yet.</span>
                ) : (
                  c.invites.map((inv) => (
                    <div className="row" key={inv.code} style={{ gap: 12 }}>
                      <span className="codebox">{inv.code}</span>
                      <span className="pmeta">
                        {ROLE_LABEL[inv.grants_role]} · used {inv.uses} of {inv.max_uses}
                      </span>
                    </div>
                  ))
                )}
              </div>
              <div className="row" style={{ marginTop: 14, gap: 8 }}>
                <form action={createInviteAction}>
                  <input type="hidden" name="circle_id" value={c.id} />
                  <input type="hidden" name="grants_role" value="member" />
                  <button className="btn sm" type="submit">New member code</button>
                </form>
                <form action={createInviteAction}>
                  <input type="hidden" name="circle_id" value={c.id} />
                  <input type="hidden" name="grants_role" value="leader" />
                  <button className="btn sm ghost" type="submit">New leader code</button>
                </form>
              </div>
            </>
          ) : null}
        </div>
      ))}
    </>
  );
}
