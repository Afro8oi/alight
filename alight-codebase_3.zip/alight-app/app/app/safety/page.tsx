import { supabaseServer } from "@/lib/supabase";
import { TIERS, CAPS } from "@/components/ui";

export const dynamic = "force-dynamic";

const COMMITMENTS: [string, string][] = [
  ["Every adult with leader powers holds a current enhanced DBS check, verified by their church, and is named on their circle page.", "Required"],
  ["Adults cannot open a private conversation with a minor. Leader-to-minor messages happen in a group thread a second adult can read.", "Enforced"],
  ["No camera roll access. Images come from the in-app camera or the curated art library.", "Enforced"],
  ["Two humans review each upload — an Alight moderator and a leader from the creator's own circle.", "Enforced"],
  ["Reports reach a duty safeguarding lead within one hour, day or night.", "1 hour"],
  ["Prayer requests that read as disclosure of harm never reach the wall. They route to a safeguarding lead.", "Enforced"],
  ["No advertising profile, no data sale, no third-party trackers. Minors' accounts are private by default.", "Committed"],
  ["No public follower counts, no read receipts, no streak-loss guilt, no infinite feed.", "By design"],
];

export default async function Safety() {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, tier, handle")
    .eq("id", user!.id)
    .single();

  const tier = (profile?.tier ?? "open") as string;

  const { count: reachable } = await supabase
    .from("profiles")
    .select("id", { count: "exact", head: true });

  const { count: myPending } = await supabase
    .from("posts")
    .select("id", { count: "exact", head: true })
    .eq("author_id", user!.id)
    .eq("status", "pending");

  return (
    <>
      <div className="vhead">
        <h1>Safety centre</h1>
        <p>
          Alight is a walled garden, not a public square. This page reports what is actually true of
          this account right now, read straight from the database.
        </p>
      </div>

      <div className="panel">
        <p style={{ fontFamily: "var(--f-display)", fontSize: "clamp(19px,3vw,25px)", fontWeight: 700, lineHeight: 1.3, maxWidth: "34ch" }}>
          No public strangers. No unreviewed uploads. No adverts. No algorithm chasing their attention.
        </p>
        <div className="tiergrid" style={{ marginTop: 16 }}>
          <div className="tier">
            <div className="lab">Your tier</div>
            <h4 style={{ marginTop: 4, textTransform: "capitalize" }}>{tier}</h4>
          </div>
          <div className="tier">
            <div className="lab">People who can reach you</div>
            <h4 style={{ marginTop: 4 }}>{Math.max(0, (reachable ?? 1) - 1)}</h4>
            <p>Confirmed members of your circles, and nobody else.</p>
          </div>
          <div className="tier">
            <div className="lab">Your posts in review</div>
            <h4 style={{ marginTop: 4 }}>{myPending ?? 0}</h4>
          </div>
          <div className="tier">
            <div className="lab">Reviewed before publish</div>
            <h4 style={{ marginTop: 4 }}>100%</h4>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="lab">Age tiers</div>
        <h3 style={{ marginTop: 6, fontSize: 17 }}>Your tier is derived from your date of birth, not chosen</h3>
        <div className="tiergrid" style={{ marginTop: 13 }}>
          {TIERS.map((t) => (
            <div className={`tier${t.id === tier ? " on" : ""}`} key={t.id}>
              <div className="age">{t.age}</div>
              <h4>{t.n}</h4>
              <p>{t.p}</p>
            </div>
          ))}
        </div>

        <div className="tablewrap" style={{ marginTop: 16 }}>
          <table className="matrix">
            <thead>
              <tr><th scope="col">Capability</th><th scope="col">On your tier</th></tr>
            </thead>
            <tbody>
              {CAPS.map((c) => {
                const v = (c as unknown as Record<string, readonly [string, string]>)[tier] ?? c.open;
                return (
                  <tr key={c.c}>
                    <td>{c.c}</td>
                    <td><span className={`state ${v[0]}`}>{v[1]}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel">
        <div className="lab">Safeguarding</div>
        <h3 style={{ marginTop: 6, fontSize: 17 }}>The things we will not compromise on</h3>
        <div className="tablewrap" style={{ marginTop: 12 }}>
          <table className="matrix">
            <tbody>
              {COMMITMENTS.map(([text, state]) => (
                <tr key={text}>
                  <td>{text}</td>
                  <td><span className="state on">{state}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
