import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase";
import { SubmitButton } from "@/components/submit-button";
import { recordDbsAction } from "@/app/actions";

export const dynamic = "force-dynamic";

const ROLE_LABEL: Record<string, string> = {
  member: "Member",
  leader: "Leader",
  safeguarding_lead: "Safeguarding lead",
};

const TIER_LABEL: Record<string, string> = {
  sprouts: "Sprouts (11–12)",
  roots: "Roots (13–15)",
  branches: "Branches (16–17)",
  open: "Open (18+)",
};

type Prof = {
  id: string;
  display_name: string;
  handle: string;
  tier: string;
  dbs_checked_on: string | null;
  dbs_expires_on: string | null;
  dbs_verified_note: string | null;
  age_vouched_by: string | null;
  age_vouched_at: string | null;
};

function ukDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function ukDateTime(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function hoursBetween(from: string, to: string) {
  return (new Date(to).getTime() - new Date(from).getTime()) / 3600000;
}

function duration(hours: number) {
  if (hours < 1) return `${Math.max(1, Math.round(hours * 60))} min`;
  if (hours < 48) return `${hours.toFixed(1)} h`;
  return `${(hours / 24).toFixed(1)} days`;
}

function dbsState(p: Prof): { label: string; cls: string } {
  if (!p.dbs_expires_on) return { label: "Not recorded", cls: "off" };
  const days = (new Date(p.dbs_expires_on).getTime() - Date.now()) / 86400000;
  if (days < 0) return { label: "Expired", cls: "bad" };
  if (days < 90) return { label: `Expires in ${Math.round(days)} days`, cls: "sup" };
  return { label: "Valid", cls: "on" };
}

export default async function Safeguarding({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; circle?: string }>;
}) {
  const { error, circle: wanted } = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: mine } = await supabase
    .from("circle_members")
    .select("circle_id, role, circles(id, name, church_name)")
    .eq("profile_id", user!.id)
    .eq("role", "safeguarding_lead");

  if (!mine?.length) redirect("/app");

  const chosen = mine.find((m) => m.circle_id === wanted) ?? mine[0];
  const circle = chosen.circles as unknown as {
    id: string; name: string; church_name: string | null;
  };

  const { data: me } = await supabase
    .from("profiles").select("display_name, handle").eq("id", user!.id).single();

  // Roster
  const { data: memberRows } = await supabase
    .from("circle_members")
    .select("role, joined_at, profiles(id, display_name, handle, tier, dbs_checked_on, dbs_expires_on, dbs_verified_note, age_vouched_by, age_vouched_at)")
    .eq("circle_id", circle.id);

  const roster = (memberRows ?? []).flatMap((m) => {
    const p = m.profiles as unknown as Prof | null;
    return p ? [{ role: m.role as string, joined_at: m.joined_at as string, ...p }] : [];
  });

  const nameById = new Map(roster.map((r) => [r.id, r.display_name]));
  const adults = roster.filter((r) => r.role !== "member");
  const youngPeople = roster.filter((r) => r.role === "member");

  // Review log
  const { data: reviewRows } = await supabase
    .from("post_reviews")
    .select("id, decision, note, created_at, reviewer_id, posts(created_at, circle_id, author_id)")
    .order("created_at", { ascending: false })
    .limit(200);

  const reviews = (reviewRows ?? []).flatMap((r) => {
    const post = r.posts as unknown as
      { created_at: string; circle_id: string; author_id: string } | null;
    if (!post || post.circle_id !== circle.id) return [];
    return [{
      id: r.id as string,
      decision: r.decision as string,
      note: r.note as string | null,
      decided_at: r.created_at as string,
      reviewer_id: r.reviewer_id as string,
      author_id: post.author_id,
      hours: hoursBetween(post.created_at, r.created_at as string),
    }];
  });

  const times = reviews.map((r) => r.hours).sort((a, b) => a - b);
  const median = times.length
    ? times.length % 2
      ? times[(times.length - 1) / 2]
      : (times[times.length / 2 - 1] + times[times.length / 2]) / 2
    : null;
  const slowest = times.length ? times[times.length - 1] : null;

  // Awaiting review right now
  const { count: awaiting } = await supabase
    .from("posts").select("id", { count: "exact", head: true })
    .eq("circle_id", circle.id).eq("status", "pending");

  // Vouching chain
  const { data: redemptions } = await supabase
    .from("invite_redemptions")
    .select("code, granted_role, redeemed_at, redeemed_by, issued_by")
    .eq("circle_id", circle.id)
    .order("redeemed_at", { ascending: false });

  // Reports
  const { data: reportRows } = await supabase
    .from("reports")
    .select("id, reason, status, created_at, resolved_at, resolution_note, reporter_id");

  const reports = reportRows ?? [];
  const openReports = reports.filter((r) => r.status === "open");

  const dbsMissing = adults.filter((a) => !a.dbs_expires_on).length;
  const dbsExpired = adults.filter(
    (a) => a.dbs_expires_on && new Date(a.dbs_expires_on).getTime() < Date.now()
  ).length;
  const vouchedCount = youngPeople.filter((p) => p.age_vouched_by).length;

  const generatedAt = new Date();

  return (
    <>
      <div className="vhead noprint">
        <h1>Safeguarding report</h1>
        <p>
          Everything below is read from the live record, not typed in. Print it, or save it as a PDF,
          and hand it to your Diocesan Safeguarding Adviser.
        </p>
        {mine.length > 1 ? (
          <div className="row" style={{ marginTop: 12 }}>
            {mine.map((m) => {
              const c = m.circles as unknown as { id: string; name: string };
              return (
                <a
                  key={c.id}
                  className={`btn sm${c.id === circle.id ? " pri" : " ghost"}`}
                  href={`/app/safeguarding?circle=${c.id}`}
                >
                  {c.name}
                </a>
              );
            })}
          </div>
        ) : null}
        <div className="row" style={{ marginTop: 14 }}>
          <a className="btn pri" href="#report">Jump to report</a>
          <span className="faint" style={{ fontSize: 13.5 }}>
            Use your browser&apos;s Print command, then &ldquo;Save as PDF&rdquo;.
          </span>
        </div>
      </div>

      {error ? <div className="alert noprint" style={{ marginBottom: 14 }}>{error}</div> : null}

      <article className="report" id="report">
        <header className="rhead">
          <div>
            <div className="lab">Safeguarding report</div>
            <h2>{circle.name}</h2>
            <div className="pmeta">
              {circle.church_name ? `${circle.church_name} · ` : ""}
              Generated {ukDateTime(generatedAt.toISOString())} by {me?.display_name} (@{me?.handle}),
              safeguarding lead
            </div>
          </div>
          <div className="rbrand">Alight</div>
        </header>

        {/* 1. Summary */}
        <section>
          <h3>1. Summary</h3>
          <div className="tablewrap">
            <table className="matrix">
              <tbody>
                <tr><td>Young people in this circle</td><td className="num">{youngPeople.length}</td></tr>
                <tr><td>Adults holding leader powers</td><td className="num">{adults.length}</td></tr>
                <tr>
                  <td>Adults without a recorded DBS check</td>
                  <td><span className={`state ${dbsMissing ? "bad" : "on"}`}>{dbsMissing}</span></td>
                </tr>
                <tr>
                  <td>Adults with an expired DBS check</td>
                  <td><span className={`state ${dbsExpired ? "bad" : "on"}`}>{dbsExpired}</span></td>
                </tr>
                <tr><td>Items reviewed before publication</td><td className="num">{reviews.length}</td></tr>
                <tr><td>Items awaiting review now</td><td className="num">{awaiting ?? 0}</td></tr>
                <tr>
                  <td>Median time from submission to decision</td>
                  <td className="num">{median === null ? "—" : duration(median)}</td>
                </tr>
                <tr>
                  <td>Slowest decision on record</td>
                  <td className="num">{slowest === null ? "—" : duration(slowest)}</td>
                </tr>
                <tr>
                  <td>Reports raised · still open</td>
                  <td className="num">{reports.length} · <span className={openReports.length ? "state bad" : ""}>{openReports.length}</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* 2. Adults */}
        <section>
          <h3>2. Adults with leader powers</h3>
          <p className="dim small">
            Alight records that a DBS certificate was seen, verified and when it expires. It does not
            store certificate numbers: once verification has happened the number has no operational use,
            and holding it would create a data-breach liability for the church.
          </p>
          <div className="tablewrap">
            <table className="matrix">
              <thead>
                <tr>
                  <th scope="col">Name</th><th scope="col">Role</th>
                  <th scope="col">Checked</th><th scope="col">Expires</th><th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {adults.map((a) => {
                  const s = dbsState(a);
                  return (
                    <tr key={a.id}>
                      <td>{a.display_name} <span className="pmeta">@{a.handle}</span></td>
                      <td>{ROLE_LABEL[a.role]}</td>
                      <td>{ukDate(a.dbs_checked_on)}</td>
                      <td>{ukDate(a.dbs_expires_on)}</td>
                      <td><span className={`state ${s.cls}`}>{s.label}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* 3. Vouching chain */}
        <section>
          <h3>3. How each young person entered this circle</h3>
          <p className="dim small">
            Nobody can create an account on Alight without a code issued in person by an adult in this
            circle. That adult vouches for the young person&apos;s age band. This is the platform&apos;s
            age-assurance method: a named, checked adult who knows the child, rather than a self-declared
            birthday or an automated face estimate.
          </p>
          <div className="tablewrap">
            <table className="matrix">
              <thead>
                <tr>
                  <th scope="col">Young person</th><th scope="col">Tier</th>
                  <th scope="col">Vouched for by</th><th scope="col">Joined</th>
                </tr>
              </thead>
              <tbody>
                {youngPeople.map((p) => (
                  <tr key={p.id}>
                    <td>{p.display_name} <span className="pmeta">@{p.handle}</span></td>
                    <td>{TIER_LABEL[p.tier] ?? p.tier}</td>
                    <td>
                      {p.age_vouched_by
                        ? (nameById.get(p.age_vouched_by) ?? "An adult no longer in this circle")
                        : <span className="state sup">Not recorded</span>}
                    </td>
                    <td>{ukDate(p.joined_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="small" style={{ marginTop: 10 }}>
            {vouchedCount} of {youngPeople.length} young people have a recorded voucher.
            {(redemptions?.length ?? 0) > 0
              ? ` ${redemptions!.length} code redemptions are logged in full below.`
              : ""}
          </p>
          {redemptions?.length ? (
            <div className="tablewrap" style={{ marginTop: 10 }}>
              <table className="matrix">
                <thead>
                  <tr>
                    <th scope="col">Code</th><th scope="col">Granted</th>
                    <th scope="col">Redeemed by</th><th scope="col">Issued by</th><th scope="col">When</th>
                  </tr>
                </thead>
                <tbody>
                  {redemptions.map((r, i) => (
                    <tr key={i}>
                      <td className="mono">{r.code}</td>
                      <td>{ROLE_LABEL[r.granted_role as string]}</td>
                      <td>{nameById.get(r.redeemed_by as string) ?? "—"}</td>
                      <td>{r.issued_by ? (nameById.get(r.issued_by as string) ?? "—") : "—"}</td>
                      <td>{ukDateTime(r.redeemed_at as string)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </section>

        {/* 4. Review log */}
        <section>
          <h3>4. Content review log</h3>
          <p className="dim small">
            No post, image or video reaches this circle without a decision recorded below. Status changes
            are only possible through the review function, which refuses anyone who is not a leader of
            this circle and refuses a leader approving their own submission.
          </p>
          {reviews.length === 0 ? (
            <p className="small">No decisions recorded yet.</p>
          ) : (
            <div className="tablewrap">
              <table className="matrix">
                <thead>
                  <tr>
                    <th scope="col">Decided</th><th scope="col">Author</th>
                    <th scope="col">Reviewer</th><th scope="col">Decision</th>
                    <th scope="col">Waited</th><th scope="col">Note</th>
                  </tr>
                </thead>
                <tbody>
                  {reviews.map((r) => (
                    <tr key={r.id}>
                      <td>{ukDateTime(r.decided_at)}</td>
                      <td>{nameById.get(r.author_id) ?? "—"}</td>
                      <td>{nameById.get(r.reviewer_id) ?? "—"}</td>
                      <td>
                        <span className={`state ${r.decision === "approve" ? "on" : r.decision === "return" ? "sup" : "bad"}`}>
                          {r.decision}
                        </span>
                      </td>
                      <td className="num">{duration(r.hours)}</td>
                      <td>{r.note ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* 5. Reports */}
        <section>
          <h3>5. Reports raised and how they were handled</h3>
          {reports.length === 0 ? (
            <p className="small">No reports have been raised in this circle.</p>
          ) : (
            <div className="tablewrap">
              <table className="matrix">
                <thead>
                  <tr>
                    <th scope="col">Raised</th><th scope="col">Reason</th>
                    <th scope="col">Status</th><th scope="col">Closed</th><th scope="col">Response time</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.map((r) => (
                    <tr key={r.id as string}>
                      <td>{ukDateTime(r.created_at as string)}</td>
                      <td>{r.reason as string}</td>
                      <td>
                        <span className={`state ${r.status === "open" ? "bad" : "on"}`}>
                          {r.status as string}
                        </span>
                      </td>
                      <td>{ukDateTime(r.resolved_at as string | null)}</td>
                      <td className="num">
                        {r.resolved_at
                          ? duration(hoursBetween(r.created_at as string, r.resolved_at as string))
                          : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* 6. Structural controls */}
        <section>
          <h3>6. Controls enforced by the platform</h3>
          <p className="dim small">
            These are properties of the database, not settings a leader can switch off. Each was tested
            by attempting to break it.
          </p>
          <div className="tablewrap">
            <table className="matrix">
              <tbody>
                <tr><td>No account can be created without a code issued by an adult in a circle</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>Every submission is held unpublished until a leader decides on it</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>An unpublished submission is visible only to its author and this circle&apos;s leaders</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>A leader cannot approve their own submission</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>A profile is readable only by people who share a circle with it</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>Age tier is derived from date of birth, never chosen by the user</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>Every review decision is written to an immutable log with reviewer and timestamp</td><td><span className="state on">Enforced</span></td></tr>
                <tr><td>No advertising profile, no third-party trackers, no data sale</td><td><span className="state on">By design</span></td></tr>
                <tr><td>Data held in the United Kingdom (London region)</td><td><span className="state on">Confirmed</span></td></tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* 7. Limitations */}
        <section>
          <h3>7. What this report cannot yet evidence</h3>
          <p className="dim small">
            Stated plainly, because a safeguarding report that overclaims is worse than none.
          </p>
          <ul className="limits">
            <li>
              <strong>Private messaging is not built.</strong> There is therefore no adult-to-minor
              message evidence in this report, because no such messages can exist on the platform yet.
            </li>
            <li>
              <strong>DBS status is self-recorded by the safeguarding lead.</strong> Alight records who
              confirmed it and when; it does not connect to the DBS update service.
            </li>
            <li>
              <strong>Age vouching is only as good as the adult who issued the code.</strong> The platform
              evidences the chain; it cannot evidence that the adult asked carefully.
            </li>
            <li>
              <strong>A second, platform-level moderator is not yet in force.</strong> Review is currently
              carried out by this circle&apos;s own leaders alone.
            </li>
          </ul>
        </section>

        <footer className="rfoot">
          <span>Alight · {circle.name} · generated {ukDateTime(generatedAt.toISOString())}</span>
        </footer>
      </article>

      {/* Recording DBS — screen only */}
      <div className="panel noprint" style={{ marginTop: 18 }}>
        <div className="lab">Record a DBS check</div>
        <h3 style={{ marginTop: 6, fontSize: 17 }}>Keep section 2 accurate</h3>
        <p className="dim" style={{ fontSize: 14, marginTop: 6 }}>
          Enter the dates from the certificate you have seen. Do not enter the certificate number —
          Alight deliberately does not store it.
        </p>
        <form action={recordDbsAction} className="stack" style={{ marginTop: 14, maxWidth: 520 }}>
          <label className="field">
            <span>Adult</span>
            <select name="subject" defaultValue={adults[0]?.id}>
              {adults.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.display_name} — {ROLE_LABEL[a.role]}
                </option>
              ))}
            </select>
          </label>
          <div className="row" style={{ gap: 12, alignItems: "flex-end" }}>
            <label className="field" style={{ flex: 1, minWidth: 150 }}>
              <span>Date checked</span>
              <input type="date" name="checked_on" required />
            </label>
            <label className="field" style={{ flex: 1, minWidth: 150 }}>
              <span>Expires</span>
              <input type="date" name="expires_on" required />
            </label>
          </div>
          <label className="field">
            <span>Who verified it</span>
            <input type="text" name="note" maxLength={200} placeholder="Seen by the Parish Safeguarding Officer, 4 Sept" />
          </label>
          <SubmitButton pendingLabel="Recording…">Record check</SubmitButton>
        </form>
      </div>
    </>
  );
}
