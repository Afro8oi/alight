import Link from "next/link";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase";
import { Wordmark, Avatar } from "@/components/ui";
import { Rail, TabBar } from "@/components/nav";
import { signOutAction } from "@/app/actions";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, handle, avatar_seed, tier")
    .eq("id", user.id)
    .single();

  const { data: memberships } = await supabase
    .from("circle_members")
    .select("role, circle_id")
    .eq("profile_id", user.id);

  const leaderCircles = (memberships ?? [])
    .filter((m) => m.role === "leader" || m.role === "safeguarding_lead")
    .map((m) => m.circle_id);

  const isSafeguardingLead = (memberships ?? []).some((m) => m.role === "safeguarding_lead");

  let pending = 0;
  if (leaderCircles.length) {
    const { count } = await supabase
      .from("posts")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending")
      .in("circle_id", leaderCircles);
    pending = count ?? 0;
  }

  const items = [
    { href: "/app", label: "Home", icon: "home" },
    { href: "/app/circles", label: "Circles", icon: "circles" },
    ...(leaderCircles.length
      ? [{ href: "/app/review", label: "Review", icon: "review", tick: pending }]
      : []),
    ...(isSafeguardingLead
      ? [{ href: "/app/safeguarding", label: "Report", icon: "report" }]
      : []),
    { href: "/app/safety", label: "Safety", icon: "shield" },
  ];

  return (
    <>
      <div className="app">
        <div className="brandbar">
          <Link href="/app" style={{ display: "flex", alignItems: "center", gap: 11 }}><Wordmark /></Link>
          <div className="spacer" />
          <Avatar seed={profile?.avatar_seed ?? 1} name={profile?.display_name ?? "?"} small />
          <form action={signOutAction}>
            <button className="btn sm ghost" type="submit">Sign out</button>
          </form>
        </div>
        <Rail items={items} />
        <main style={{ minWidth: 0 }}>{children}</main>
      </div>
      <TabBar items={items} />
    </>
  );
}
