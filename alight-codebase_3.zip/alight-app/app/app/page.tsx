import Link from "next/link";
import { supabaseServer, type PostCard } from "@/lib/supabase";
import { Avatar, StatusChip, ArtPanel, timeAgo, Icon } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import {
  createPostAction,
  reactAction,
  checkInviteAction,
  pendingInviteCode,
} from "@/app/actions";

export const dynamic = "force-dynamic";

const REACTIONS: { kind: "amen" | "praying" | "love"; label: string; countKey: keyof PostCard }[] = [
  { kind: "amen", label: "Amen", countKey: "amen_count" },
  { kind: "praying", label: "Praying", countKey: "praying_count" },
  { kind: "love", label: "Love this", countKey: "love_count" },
];

export default async function Feed({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; sent?: string }>;
}) {
  const { error, sent } = await searchParams;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: memberships } = await supabase
    .from("circle_members")
    .select("circle_id, role, circles(name)")
    .eq("profile_id", user!.id);

  const circles = (memberships ?? []).map((m) => ({
    id: m.circle_id as string,
    name: (m.circles as unknown as { name: string } | null)?.name ?? "Circle",
  }));

  if (!circles.length) {
    const saved = await pendingInviteCode();
    return (
      <div className="vhead">
        <h1>You are not in a circle yet</h1>
        {saved ? (
          <>
            <p>
              Your account is ready. One thing left — join the circle your code belongs to.
            </p>
            {error ? <div className="alert" style={{ marginTop: 14 }}>{error}</div> : null}
            <form action={checkInviteAction} style={{ marginTop: 16 }}>
              <input type="hidden" name="code" value={saved} />
              <SubmitButton pendingLabel="Joining…">
                Join with code {saved}
              </SubmitButton>
            </form>
            <p className="faint" style={{ fontSize: 13.5, marginTop: 12 }}>
              Not your code? <Link href="/join">Enter a different one</Link>.
            </p>
          </>
        ) : (
          <>
            <p>Alight only works inside a circle. Enter the code your youth leader gave you.</p>
            <Link className="btn pri" href="/join" style={{ marginTop: 16 }}>Enter my code</Link>
          </>
        )}
      </div>
    );
  }

  const { data: posts } = await supabase
    .from("post_cards")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(60);

  const cards = (posts ?? []) as PostCard[];

  return (
    <>
      <div className="vhead">
        <h1>{circles.length === 1 ? circles[0].name : "Your circles"}</h1>
        <p>
          Nothing here reaches strangers, and nothing is published before a human has read it.
        </p>
      </div>

      {error ? <div className="alert" style={{ marginBottom: 14 }}>{error}</div> : null}
      {sent ? (
        <div className="alert good" style={{ marginBottom: 14 }}>
          Sent for review. A leader from your circle sees it next — you will find it below marked
          &ldquo;In review&rdquo; until they do.
        </div>
      ) : null}

      <form action={createPostAction} className="panel" style={{ marginBottom: 16 }}>
        <label className="field">
          <span className="lab">New post</span>
          <textarea
            name="body"
            maxLength={2000}
            required
            placeholder="What happened? What are you reading? Who needs praying for?"
          />
        </label>

        {circles.length > 1 ? (
          <label className="field" style={{ marginTop: 12 }}>
            <span>Going to</span>
            <select name="circle_id" defaultValue={circles[0].id}>
              {circles.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </label>
        ) : (
          <input type="hidden" name="circle_id" value={circles[0].id} />
        )}

        <div className="lab" style={{ marginTop: 14 }}>Add a card from the art library</div>
        <div className="artpick">
          <label>
            <input type="radio" name="art_id" value="0" defaultChecked />
            <span className="artswatch none">NONE</span>
          </label>
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <label key={i}>
              <input type="radio" name="art_id" value={i} />
              <span className="artswatch"><span className="art" data-art={i} /></span>
            </label>
          ))}
        </div>

        <div className="notice" style={{ marginTop: 14 }}>
          There is no camera roll here on purpose. Cards come from the Alight art library.
        </div>

        <SubmitButton style={{ marginTop: 14 }} pendingLabel="Sending for review…">
          Send for review
        </SubmitButton>
      </form>

      {cards.length === 0 ? (
        <div className="empty">
          Nothing has been approved in your circle yet. Be the first — write something above.
        </div>
      ) : (
        <div className="feed">
          {cards.map((p) => {
            const mine = p.author_id === user!.id;
            return (
              <article key={p.id} className={`post${mine && p.status !== "approved" ? " mine-pending" : ""}`}>
                <div className="phead">
                  <Avatar seed={p.avatar_seed} name={p.display_name} />
                  <div style={{ minWidth: 0 }}>
                    <div className="pname">{p.display_name}</div>
                    <div className="pmeta">
                      @{p.handle} · {timeAgo(p.published_at ?? p.created_at)} · {p.circle_name}
                    </div>
                  </div>
                  <div className="spacer" />
                  <StatusChip status={p.status} />
                </div>

                <div className="pbody">{p.body}</div>
                {p.art_id ? <ArtPanel id={p.art_id} /> : null}

                {p.status === "returned" && p.review_note ? (
                  <div className="alert" style={{ margin: "0 14px 12px", borderRadius: "var(--r-m)" }}>
                    <strong>A leader sent this back:</strong> {p.review_note}
                  </div>
                ) : null}

                {p.status === "approved" ? (
                  <div className="pfoot">
                    {REACTIONS.map((r) => {
                      const on = p.my_reactions?.includes(r.kind);
                      return (
                        <form key={r.kind} action={reactAction}>
                          <input type="hidden" name="post_id" value={p.id} />
                          <input type="hidden" name="kind" value={r.kind} />
                          <button
                            className={`react${r.kind === "praying" ? " pray" : ""}${on ? " on" : ""}`}
                            type="submit"
                            aria-pressed={on}
                          >
                            {r.label} <span className="n num">{Number(p[r.countKey] ?? 0)}</span>
                          </button>
                        </form>
                      );
                    })}
                    <div className="spacer" />
                    <span className="chip led">
                      <Icon name="shield" size={12} width={2.2} />Circle only
                    </span>
                  </div>
                ) : null}
              </article>
            );
          })}
        </div>
      )}
    </>
  );
}
