"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { supabaseServer } from "@/lib/supabase";

function back(path: string, error: string) {
  redirect(`${path}${path.includes("?") ? "&" : "?"}error=${encodeURIComponent(error)}`);
}

// Where a pending invite code waits while the user goes to confirm their email.
const INVITE_COOKIE = "alight_invite";

export async function pendingInviteCode() {
  const store = await cookies();
  return store.get(INVITE_COOKIE)?.value ?? null;
}

/* ---------------- joining ---------------- */

export async function checkInviteAction(formData: FormData) {
  const code = String(formData.get("code") ?? "").trim().toUpperCase();
  if (!/^[A-Z0-9]{6,12}$/.test(code)) {
    back("/join", "That does not look like an Alight code. They are 6 to 12 letters and numbers.");
  }

  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();

  // Signed in already: redeem it now.
  if (user) {
    const { error } = await supabase.rpc("redeem_invite", { invite_code: code });
    if (error) back("/join", error.message);
    (await cookies()).delete(INVITE_COOKIE);
    revalidatePath("/app");
    redirect("/app");
  }

  const { data, error } = await supabase.rpc("check_invite", { invite_code: code });
  if (error) back("/join", error.message);

  const row = Array.isArray(data) ? data[0] : data;
  if (!row || !row.valid) {
    back("/join", "That code is not valid any more. Ask your leader for a fresh one.");
  }

  redirect(`/signup?code=${code}&circle=${encodeURIComponent(row.circle_name)}`);
}

/* ---------------- accounts ---------------- */

export async function signUpAction(formData: FormData) {
  const code = String(formData.get("code") ?? "").trim().toUpperCase();
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const displayName = String(formData.get("display_name") ?? "").trim();
  const handle = String(formData.get("handle") ?? "").trim().toLowerCase();
  const dob = String(formData.get("date_of_birth") ?? "");
  const backTo = `/signup?code=${code}`;

  if (displayName.length < 2) back(backTo, "Tell us what to call you.");
  if (!/^[a-z0-9_]{3,20}$/.test(handle)) {
    back(backTo, "Usernames are 3 to 20 characters: lower-case letters, numbers and underscores.");
  }
  if (password.length < 8) back(backTo, "Use at least 8 characters for your password.");
  if (!dob) back(backTo, "We need your date of birth to set the right safety tier.");

  const age = (Date.now() - new Date(dob).getTime()) / 31557600000;
  if (age < 11) back(backTo, "Alight is for ages 11 and over.");
  if (age > 100) back(backTo, "Please check that date of birth.");

  const supabase = await supabaseServer();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { display_name: displayName, handle, date_of_birth: dob } },
  });

  if (error) back(backTo, error.message);

  // Email confirmation off: we have a session, so redeem the code straight away.
  if (data.session) {
    const { error: joinError } = await supabase.rpc("redeem_invite", { invite_code: code });
    if (joinError) back("/join", joinError.message);
    (await cookies()).delete(INVITE_COOKIE);
    revalidatePath("/app");
    redirect("/app");
  }

  // Email confirmation on: there is no session yet, so the code cannot be redeemed
  // here. Keep it on this device so that whichever way the user comes back —
  // the link in their inbox, or signing in later — the code is still waiting.
  (await cookies()).set(INVITE_COOKIE, code, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 14,
  });

  redirect(`/login?confirm=1&code=${code}`);
}

export async function signInAction(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "/app");

  const supabase = await supabaseServer();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) back("/login", "That email and password do not match an Alight account.");

  revalidatePath("/app");
  redirect(next.startsWith("/") ? next : "/app");
}

export async function signOutAction() {
  const supabase = await supabaseServer();
  await supabase.auth.signOut();
  revalidatePath("/");
  redirect("/");
}

/* ---------------- posting ---------------- */

export async function createPostAction(formData: FormData) {
  const body = String(formData.get("body") ?? "").trim();
  const circleId = String(formData.get("circle_id") ?? "");
  const artRaw = String(formData.get("art_id") ?? "");
  const artId = artRaw && artRaw !== "0" ? Number(artRaw) : null;

  if (body.length < 1) back("/app", "Write something first.");
  if (body.length > 2000) back("/app", "That is longer than a post can be — 2000 characters is the limit.");
  if (!circleId) back("/app", "Choose which circle this is going to.");

  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { error } = await supabase
    .from("posts")
    .insert({ circle_id: circleId, author_id: user.id, body, art_id: artId });

  if (error) {
    // 23505: the duplicate guard caught a double-tap or a resubmitted refresh.
    // The first copy is already in the queue, so treat this as success.
    if (error.code === "23505") redirect("/app?sent=1");
    back("/app", error.message);
  }

  revalidatePath("/app");
  redirect("/app?sent=1");
}

export async function reactAction(formData: FormData) {
  const postId = String(formData.get("post_id") ?? "");
  const kind = String(formData.get("kind") ?? "");
  const supabase = await supabaseServer();
  await supabase.rpc("toggle_reaction", { target_post: postId, k: kind });
  revalidatePath("/app");
}

export async function reviewAction(formData: FormData) {
  const postId = String(formData.get("post_id") ?? "");
  const decision = String(formData.get("decision") ?? "");
  const note = String(formData.get("note") ?? "").trim() || null;

  const supabase = await supabaseServer();
  const { error } = await supabase.rpc("review_post", {
    target_post: postId,
    decision,
    note,
  });
  if (error) back("/app/review", error.message);

  revalidatePath("/app/review");
  revalidatePath("/app");
}

/* ---------------- leader tools ---------------- */

export async function createInviteAction(formData: FormData) {
  const circleId = String(formData.get("circle_id") ?? "");
  const role = String(formData.get("grants_role") ?? "member");

  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no O/0, no I/1
  let code = "";
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  bytes.forEach((b) => (code += alphabet[b % alphabet.length]));

  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { error } = await supabase.from("circle_invites").insert({
    code,
    circle_id: circleId,
    grants_role: role,
    issued_by: user.id,
    max_uses: role === "member" ? 50 : 5,
    expires_at: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(),
  });
  if (error) back("/app/circles", error.message);

  revalidatePath("/app/circles");
}

/* ---------------- safeguarding ---------------- */

export async function recordDbsAction(formData: FormData) {
  const subject = String(formData.get("subject") ?? "");
  const checkedOn = String(formData.get("checked_on") ?? "");
  const expiresOn = String(formData.get("expires_on") ?? "");
  const note = String(formData.get("note") ?? "").trim() || null;

  if (!checkedOn || !expiresOn) {
    back("/app/safeguarding", "Both the check date and the expiry date are needed.");
  }

  const supabase = await supabaseServer();
  const { error } = await supabase.rpc("record_dbs", {
    subject,
    checked_on: checkedOn,
    expires_on: expiresOn,
    note,
  });
  if (error) back("/app/safeguarding", error.message);

  revalidatePath("/app/safeguarding");
  revalidatePath("/app/circles");
}

export async function resolveReportAction(formData: FormData) {
  const reportId = String(formData.get("report_id") ?? "");
  const note = String(formData.get("note") ?? "").trim() || null;

  const supabase = await supabaseServer();
  const { error } = await supabase.rpc("resolve_report", {
    target_report: reportId,
    note,
  });
  if (error) back("/app/safeguarding", error.message);

  revalidatePath("/app/safeguarding");
}
