import Link from "next/link";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase";
import { Wordmark, Icon } from "@/components/ui";

export default async function Landing() {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/app");

  return (
    <div className="authwrap">
      <div className="row" style={{ marginBottom: 26 }}><Wordmark /></div>

      <h1 style={{ fontSize: "clamp(30px,7vw,42px)", lineHeight: 1.08 }}>
        Come as you are.<br />Leave alight.
      </h1>
      <p className="dim" style={{ marginTop: 14, fontSize: 16.5, maxWidth: "34ch" }}>
        A social platform built for youth groups, where the safety is the architecture rather than a
        settings page.
      </p>

      <div className="stack" style={{ marginTop: 26, gap: 10 }}>
        {[
          "You cannot join without a code from a youth leader.",
          "Every post is read by a human before anyone else sees it.",
          "No strangers, no adverts, no camera roll, no infinite feed.",
        ].map((line) => (
          <div className="row" key={line} style={{ gap: 11, flexWrap: "nowrap", alignItems: "flex-start" }}>
            <span style={{ color: "var(--glass)", marginTop: 3 }}><Icon name="check" size={17} width={2.6} /></span>
            <span style={{ fontSize: 15 }}>{line}</span>
          </div>
        ))}
      </div>

      <div className="row" style={{ marginTop: 28, gap: 10 }}>
        <Link className="btn pri" href="/join">I have an invite code</Link>
        <Link className="btn ghost" href="/login">Sign in</Link>
      </div>

      <div className="notice" style={{ marginTop: 28 }}>
        Leaders: your circle&apos;s invite codes live on the Circles page once you are signed in.
      </div>
    </div>
  );
}
