import Link from "next/link";
import { Wordmark } from "@/components/ui";
import { signInAction } from "@/app/actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string; confirm?: string; code?: string }>;
}) {
  const { error, next, confirm, code } = await searchParams;

  return (
    <div className="authwrap">
      <div className="row" style={{ marginBottom: 22 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 11 }}><Wordmark /></Link>
      </div>

      <div className="authcard">
        <h1>Welcome back</h1>

        {confirm ? (
          <div className="alert good" style={{ marginTop: 16 }}>
            Your account is made. Confirm your email address, then sign in here
            {code ? <> and enter your code <strong>{code}</strong> to join your circle</> : null}.
          </div>
        ) : null}
        {error ? <div className="alert" style={{ marginTop: 16 }}>{error}</div> : null}

        <form action={signInAction} className="stack" style={{ marginTop: 18 }}>
          <input type="hidden" name="next" value={next ?? "/app"} />
          <label className="field">
            <span>Email</span>
            <input type="email" name="email" required autoComplete="email" autoFocus />
          </label>
          <label className="field">
            <span>Password</span>
            <input type="password" name="password" required autoComplete="current-password" />
          </label>
          <button className="btn pri" style={{ width: "100%", marginTop: 6 }} type="submit">
            Sign in
          </button>
        </form>

        <div className="divider" />
        <p className="faint" style={{ fontSize: 13.5 }}>
          New here? You need a code from your youth leader — <Link href="/join">start there</Link>.
        </p>
      </div>
    </div>
  );
}
