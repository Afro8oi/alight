import Link from "next/link";
import { redirect } from "next/navigation";
import { Wordmark } from "@/components/ui";
import { signUpAction } from "@/app/actions";

export default async function SignupPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string; circle?: string; error?: string }>;
}) {
  const { code, circle, error } = await searchParams;
  if (!code) redirect("/join");

  return (
    <div className="authwrap">
      <div className="row" style={{ marginBottom: 22 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 11 }}><Wordmark /></Link>
      </div>

      <div className="authcard">
        <div className="steps"><i className="on" /><i className="on" /><i /></div>
        <h1>Make your account</h1>
        {circle ? (
          <p className="dim" style={{ marginTop: 8, fontSize: 15 }}>
            This code puts you in <strong style={{ color: "var(--text)" }}>{circle}</strong>.
          </p>
        ) : null}

        {error ? <div className="alert" style={{ marginTop: 16 }}>{error}</div> : null}

        <form action={signUpAction} className="stack" style={{ marginTop: 18 }}>
          <input type="hidden" name="code" value={code} />

          <label className="field">
            <span>Your name, as your circle knows you</span>
            <input type="text" name="display_name" maxLength={40} required autoComplete="name" />
          </label>

          <label className="field">
            <span>Username</span>
            <input
              type="text"
              name="handle"
              maxLength={20}
              required
              placeholder="amara"
              autoCapitalize="none"
              spellCheck={false}
              pattern="[a-zA-Z0-9_]{3,20}"
            />
          </label>

          <label className="field">
            <span>Date of birth</span>
            <input type="date" name="date_of_birth" required />
            <span className="faint" style={{ fontSize: 12.5 }}>
              This sets your safety tier. It is never shown on your profile.
            </span>
          </label>

          <label className="field">
            <span>Email</span>
            <input type="email" name="email" required autoComplete="email" />
          </label>

          <label className="field">
            <span>Password</span>
            <input type="password" name="password" minLength={8} required autoComplete="new-password" />
          </label>

          <button className="btn pri" style={{ width: "100%", marginTop: 6 }} type="submit">
            Create my account
          </button>
        </form>

        <div className="notice" style={{ marginTop: 18 }}>
          Under 16? Your account is parent-linked and your posts go to a leader before anyone sees them.
          That does not change as you use the app.
        </div>
      </div>
    </div>
  );
}
