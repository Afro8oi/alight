import Link from "next/link";
import { Wordmark } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { checkInviteAction, pendingInviteCode } from "@/app/actions";

export default async function JoinPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const saved = await pendingInviteCode();

  return (
    <div className="authwrap">
      <div className="row" style={{ marginBottom: 22 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 11 }}><Wordmark /></Link>
      </div>

      <div className="authcard">
        <div className="steps"><i className="on" /><i /><i /></div>
        <h1>What is your code?</h1>
        <p className="dim" style={{ marginTop: 8, fontSize: 15 }}>
          Alight has no open sign-up. Your youth leader gives you a code, and that code is what puts you
          in their circle.
        </p>

        {error ? <div className="alert" style={{ marginTop: 16 }}>{error}</div> : null}
        {saved && !error ? (
          <div className="alert good" style={{ marginTop: 16 }}>
            We kept the code you started with. Check it is right and carry on.
          </div>
        ) : null}

        <form action={checkInviteAction} style={{ marginTop: 18 }}>
          <label className="field">
            <span className="sr">Invite code</span>
            <input
              className="code-input"
              name="code"
              placeholder="ABC123"
              defaultValue={saved ?? ""}
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              maxLength={12}
              required
              autoFocus
            />
          </label>
          <SubmitButton
            className="btn pri"
            style={{ width: "100%", marginTop: 16 }}
            pendingLabel="Checking…"
          >
            Continue
          </SubmitButton>
        </form>

        <div className="divider" />
        <p className="faint" style={{ fontSize: 13.5 }}>
          Already have an account? <Link href="/login">Sign in</Link> and enter the code from there.
        </p>
      </div>
    </div>
  );
}
