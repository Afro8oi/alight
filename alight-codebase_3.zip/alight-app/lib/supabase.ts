import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

// The project URL and publishable key are designed to be public: every rule that
// protects data lives in row-level security on the database, not in this string.
export const SUPABASE_URL =
  process.env.NEXT_PUBLIC_SUPABASE_URL ?? "https://rjcuwaktwzzicxgbhfvn.supabase.co";
export const SUPABASE_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ??
  "sb_publishable_sf---yseSJjTSsCBiJeT7w_YUuCIBMB";

export async function supabaseServer() {
  const store = await cookies();
  return createServerClient(SUPABASE_URL, SUPABASE_KEY, {
    cookies: {
      getAll() {
        return store.getAll();
      },
      setAll(list) {
        try {
          list.forEach(({ name, value, options }) => store.set(name, value, options));
        } catch {
          // Called from a server component render; the middleware refreshes instead.
        }
      },
    },
  });
}

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(SUPABASE_URL, SUPABASE_KEY, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(list) {
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isAppRoute = path.startsWith("/app");

  if (!user && isAppRoute) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", path);
    return NextResponse.redirect(url);
  }

  return response;
}

export type Tier = "sprouts" | "roots" | "branches" | "open";
export type MemberRole = "member" | "leader" | "safeguarding_lead";
export type PostStatus = "pending" | "approved" | "returned" | "removed";
export type ReactionKind = "amen" | "praying" | "love";

export type PostCard = {
  id: string;
  circle_id: string;
  circle_name: string;
  author_id: string;
  display_name: string;
  handle: string;
  avatar_seed: number;
  body: string;
  art_id: number | null;
  status: PostStatus;
  review_note: string | null;
  created_at: string;
  published_at: string | null;
  amen_count: number;
  praying_count: number;
  love_count: number;
  my_reactions: ReactionKind[];
};
